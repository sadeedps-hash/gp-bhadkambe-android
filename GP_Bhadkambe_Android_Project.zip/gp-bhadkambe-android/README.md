# Gram Panchayat Bhadkambe - Android App

Android WebView wrapper for the Gram Panchayat inward/outward register.

## Firebase setup required before first build/use
1. In Firebase Console, open project `gp-bhadkambe` and add a **Web app** (</> icon) if you have not already.
2. Copy the Web app config values into `app/src/main/assets/firebase-config.js`: `apiKey` and the Web app `appId`. Do not use the Android `mobilesdk_app_id` in the `appId` field.
3. Confirm `databaseURL` exactly matches the URL shown in Firebase Console > Realtime Database.
4. In Firebase Authentication, enable Email/Password and create the staff login.
5. Set Realtime Database rules to allow authenticated access only to `gp_bhadkambe/register`:

```json
{
  "rules": {
    "gp_bhadkambe": {
      "register": {
        ".read": "auth != null",
        ".write": "auth != null"
      }
    }
  }
}
```

## Build
GitHub Actions builds a debug APK on push to `main` or when manually run from Actions. Download it from the workflow run's Artifacts section.

## Important data note
The app stores compressed application photos as data URLs in the Realtime Database register. Keep photos small; Realtime Database is not a dedicated photo-storage service and large photo collections can use quota quickly. Keep regular JSON backups. This project does not include Cloud Storage, which requires a billing-plan upgrade in the current Firebase setup.
